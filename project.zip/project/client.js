const express = require("express");
const app = express();
//for loading images
app.use(express.static('images'));

//const app = require("express")();
//const app = express();
app.use(express.static('images'));
app.get("/", (req, res)=>{
    res.sendFile(__dirname + "/login.html");
})
app.get("/home.html", (req, res)=>{
    res.sendFile(__dirname + "/home.html");
})
app.get("/UI.html", (req, res)=>{
    res.sendFile(__dirname + "/UI.html");
})
app.get("/contact.html", (req, res)=>{
    res.sendFile(__dirname + "/contact.html");
})
app.get("/course.html", (req, res)=>{
    res.sendFile(__dirname + "/course.html");
})

app.listen(3333, ()=>{
    console.log("Client App running at 3333");
})